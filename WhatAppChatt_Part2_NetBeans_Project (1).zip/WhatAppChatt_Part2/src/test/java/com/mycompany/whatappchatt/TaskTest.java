package com.mycompany.whatappchatt;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Task class - PROG5121 POE Part 2
 */
public class TaskTest {

    @BeforeEach
    public void setUp() {
        // Reset the static counter before each test so Task Numbers start from 0
        Task.resetTaskCounter();
    }

    // ---------- checkTaskDescription Tests ----------
    @Test
    public void testCheckTaskDescription_Valid() {
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertTrue(task.checkTaskDescription());
    }

    @Test
    public void testCheckTaskDescription_TooLong() {
        // Description longer than 50 characters
        String longDesc = "This description is deliberately made longer than fifty characters to fail the check";
        Task task = new Task("Login Feature", longDesc, "Robyn Harrison", 8, "To Do");
        assertFalse(task.checkTaskDescription());
    }

    // ---------- createTaskID Tests ----------
    @Test
    public void testCreateTaskID_CorrectFormat() {
        // First task → number 0
        // Task Name "Add Task Feature" → AD
        // Developer "Mike Smith" → last 3 letters = ITH
        Task task = new Task("Add Task Feature", "Create Add Task feature to add task users", "Mike Smith", 10, "Doing");
        String id = task.getTaskID();
        assertEquals("AD:0:ITH", id);
    }

    @Test
    public void testCreateTaskID_SecondTask() {
        // Create first task so counter becomes 1 for the second
        new Task("First Task", "Short desc", "John Doe", 5, "To Do");
        Task task2 = new Task("Login Feature", "Create Login", "Robyn Harrison", 8, "To Do");
        // LO:1:SON  (Harrison → last 3 = SON)
        assertEquals("LO:1:SON", task2.getTaskID());
    }

    // ---------- printTaskDetails Test ----------
    @Test
    public void testPrintTaskDetails_ContainsRequiredFields() {
        Task task = new Task("Add Task Feature", "Create Add Task feature", "Mike Smith", 10, "To Do");
        String details = task.printTaskDetails();

        assertTrue(details.contains("Task Status: To Do"));
        assertTrue(details.contains("Developer Details: Mike Smith"));
        assertTrue(details.contains("Task Number: 0"));
        assertTrue(details.contains("Task Name: Add Task Feature"));
        assertTrue(details.contains("Task Description: Create Add Task feature"));
        assertTrue(details.contains("Task ID: AD:0:ITH"));
        assertTrue(details.contains("Task Duration: 10 hours"));
    }

    // ---------- returnTotalHours Test ----------
    @Test
    public void testReturnTotalHours() {
        Task task = new Task("Test Task", "Description", "Dev Name", 15, "Done");
        assertEquals(15, task.returnTotalHours());
    }

    @Test
    public void testReturnTotalHours_MultipleTasks() {
        Task t1 = new Task("Task One", "Desc one", "Alice Brown", 5, "To Do");
        Task t2 = new Task("Task Two", "Desc two", "Bob Green", 8, "Doing");
        Task t3 = new Task("Task Three", "Desc three", "Carol White", 12, "Done");

        int total = t1.returnTotalHours() + t2.returnTotalHours() + t3.returnTotalHours();
        assertEquals(25, total);
    }
}
