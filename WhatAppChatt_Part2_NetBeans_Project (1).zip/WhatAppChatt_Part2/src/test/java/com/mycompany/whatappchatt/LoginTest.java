package com.mycompany.whatappchatt;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Login class - PROG5121 POE Part 1
 */
public class LoginTest {

    private final Login login = new Login();

    @Test
    public void testCheckUserName_Correct() {
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testCheckUserName_Incorrect() {
        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }

    @Test
    public void testCheckPasswordComplexity_Correct() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testCheckPasswordComplexity_Incorrect() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testRegisterUser_Success() {
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith");
        assertTrue(result.contains("Username successfully captured"));
        assertTrue(result.contains("Password successfully captured"));
    }

    @Test
    public void testRegisterUser_BadUsername() {
        String result = login.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!", "Kyle", "Smith");
        assertEquals(
            "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.",
            result);
    }

    @Test
    public void testRegisterUser_BadPassword() {
        String result = login.registerUser("kyl_1", "password", "Kyle", "Smith");
        assertEquals(
            "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.",
            result);
    }

    @Test
    public void testLoginUser_Success() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginUser_Failed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith");
        assertFalse(login.loginUser("wrong", "wrong"));
    }

    @Test
    public void testReturnLoginStatus_Success() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith");
        String msg = login.returnLoginStatus("kyl_1", "Ch&&sec@ke99!");
        assertEquals("Welcome Kyle ,Smith it is great to see you again.", msg);
    }

    @Test
    public void testReturnLoginStatus_Failed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith");
        String msg = login.returnLoginStatus("wrong", "wrong");
        assertEquals("Username or password incorrect, please try again", msg);
    }
}
