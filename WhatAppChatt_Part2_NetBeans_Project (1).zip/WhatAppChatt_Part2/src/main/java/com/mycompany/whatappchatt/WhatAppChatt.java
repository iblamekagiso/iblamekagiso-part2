package com.mycompany.whatappchatt;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * Main class for PROG5121 POE Part 2 - EasyKanban
 * Registration + Login (Part 1) then Task management menu (Part 2)
 *
 * @author Student
 */
public class WhatAppChatt {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        // ========== PART 1: REGISTRATION ==========
        System.out.println("=== REGISTRATION ===");

        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        String regMessage = login.registerUser(username, password, firstName, lastName);
        System.out.println(regMessage);

        // Only continue if registration succeeded
        if (!regMessage.contains("successfully captured")) {
            System.out.println("Registration failed. Exiting.");
            scanner.close();
            return;
        }

        // ========== PART 1: LOGIN ==========
        System.out.println("\n=== LOGIN ===");

        System.out.print("Enter username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = scanner.nextLine();

        String loginMessage = login.returnLoginStatus(loginUsername, loginPassword);
        System.out.println(loginMessage);

        // Only allow access to EasyKanban if login was successful
        if (!login.loginUser(loginUsername, loginPassword)) {
            System.out.println("Login failed. Exiting.");
            scanner.close();
            return;
        }

        // ========== PART 2: EASYKANBAN ==========
        System.out.println("\nWelcome to EasyKanban");

        boolean running = true;
        int totalHours = 0;

        while (running) {
            System.out.println("\n--- MENU ---");
            System.out.println("1) Add tasks");
            System.out.println("2) Show report - Coming Soon");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    totalHours += addTasks(scanner);
                    System.out.println("\nTotal hours across all tasks so far: " + totalHours);
                    break;

                case "2":
                    System.out.println("Coming Soon");
                    break;

                case "3":
                    System.out.println("Exiting EasyKanban. Goodbye!");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid option. Please choose 1, 2 or 3.");
                    break;
            }
        }

        scanner.close();
    }

    /**
     * Handles the "Add tasks" feature.
     * Asks how many tasks the user wants to enter, then captures each one.
     * Returns the total hours of the tasks added in this session.
     */
    private static int addTasks(Scanner scanner) {
        System.out.print("How many tasks do you wish to enter? ");
        int numTasks;

        try {
            numTasks = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number. Returning to menu.");
            return 0;
        }

        if (numTasks <= 0) {
            System.out.println("Number of tasks must be greater than 0.");
            return 0;
        }

        int sessionHours = 0;

        for (int i = 0; i < numTasks; i++) {
            System.out.println("\n--- Entering Task " + (i + 1) + " of " + numTasks + " ---");

            System.out.print("Task Name: ");
            String taskName = scanner.nextLine();

            System.out.print("Task Description (max 50 characters): ");
            String taskDescription = scanner.nextLine();

            // Validate description length BEFORE creating the Task object
            if (taskDescription == null || taskDescription.length() > 50) {
                System.out.println("Please enter a task description of less than 50 characters");
            } else {
                System.out.println("Task successfully captured");
            }

            System.out.print("Developer First Name: ");
            String devFirst = scanner.nextLine();
            System.out.print("Developer Last Name: ");
            String devLast = scanner.nextLine();
            String developerDetails = devFirst + " " + devLast;

            System.out.print("Task Duration (hours): ");
            int duration;
            try {
                duration = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid duration. Using 0.");
                duration = 0;
            }

            // Task Status menu
            System.out.println("Select Task Status:");
            System.out.println("1) To Do");
            System.out.println("2) Doing");
            System.out.println("3) Done");
            System.out.print("Choice: ");
            String statusChoice = scanner.nextLine().trim();
            String taskStatus;
            switch (statusChoice) {
                case "2":
                    taskStatus = "Doing";
                    break;
                case "3":
                    taskStatus = "Done";
                    break;
                default:
                    taskStatus = "To Do";
                    break;
            }

            // Create the real Task object (this increments the task number)
            Task task = new Task(taskName, taskDescription, developerDetails, duration, taskStatus);

            // Display full details (using both console and JOptionPane as required)
            String details = task.printTaskDetails();
            System.out.println("\n" + details);

            // Show in a popup as required by the brief
            JOptionPane.showMessageDialog(null, details, "Task Details", JOptionPane.INFORMATION_MESSAGE);

            sessionHours += task.returnTotalHours();
        }

        return sessionHours;
    }
}
