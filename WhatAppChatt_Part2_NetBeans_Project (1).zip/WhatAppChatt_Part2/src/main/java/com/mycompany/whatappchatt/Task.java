package com.mycompany.whatappchatt;

/**
 * Task class for PROG5121 POE Part 2 - EasyKanban
 * Stores and manages individual task details
 */
public class Task {

    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;

    // Static counter so task numbers auto-increment across all tasks
    private static int taskCounter = 0;

    /**
     * Constructor - creates a new task and auto-generates Task Number and Task ID
     */
    public Task(String taskName, String taskDescription, String developerDetails,
                int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskCounter;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskID = createTaskID();
        taskCounter++;
    }

    /**
     * Checks that the task description is not more than 50 characters.
     * @return true if description length <= 50, false otherwise
     */
    public boolean checkTaskDescription() {
        return taskDescription != null && taskDescription.length() <= 50;
    }

    /**
     * Creates the Task ID in the format:
     * First two letters of Task Name (uppercase) + ":" + Task Number + ":" + last three letters of Developer name (uppercase)
     * Example: AD:0:INA
     * @return the generated Task ID
     */
    public String createTaskID() {
        String namePart;
        if (taskName == null || taskName.length() < 2) {
            namePart = (taskName == null ? "XX" : (taskName + "X").substring(0, 2));
        } else {
            namePart = taskName.substring(0, 2);
        }

        String devPart;
        if (developerDetails == null || developerDetails.length() < 3) {
            devPart = (developerDetails == null ? "XXX" : (developerDetails + "XXX").substring(0, 3));
        } else {
            // Use the last three characters of the developer details
            devPart = developerDetails.substring(developerDetails.length() - 3);
        }

        return (namePart + ":" + taskNumber + ":" + devPart).toUpperCase();
    }

    /**
     * Returns the full details of the task as a formatted string.
     * Order required by the brief:
     * Task Status, Developer Details, Task Number, Task Name, Task Description, Task ID, Duration
     */
    public String printTaskDetails() {
        return "Task Status: " + taskStatus
                + "\nDeveloper Details: " + developerDetails
                + "\nTask Number: " + taskNumber
                + "\nTask Name: " + taskName
                + "\nTask Description: " + taskDescription
                + "\nTask ID: " + taskID
                + "\nTask Duration: " + taskDuration + " hours";
    }

    /**
     * Returns the duration of this task (used to calculate total hours).
     */
    public int returnTotalHours() {
        return taskDuration;
    }

    // ========== Getters ==========
    public String getTaskName() {
        return taskName;
    }

    public int getTaskNumber() {
        return taskNumber;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public String getDeveloperDetails() {
        return developerDetails;
    }

    public int getTaskDuration() {
        return taskDuration;
    }

    public String getTaskID() {
        return taskID;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    /**
     * Resets the static counter (useful for unit tests so they start from 0).
     */
    public static void resetTaskCounter() {
        taskCounter = 0;
    }
}
